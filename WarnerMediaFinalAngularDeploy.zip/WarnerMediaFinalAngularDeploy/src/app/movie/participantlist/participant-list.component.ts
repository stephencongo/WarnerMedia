import {Component, OnInit} from '@angular/core';
import { Movie } from 'src/app/shared/objects/movie';
import { MovieService } from 'src/app/shared/services/movie.service';
import { catchError, tap, map } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'pm-participantlist',
    templateUrl: './participant-list.component.html',
    styleUrls: ['./participant-list.component.css']
})

export class ParticipantListComponent implements OnInit {
    pageTitle = 'Participant List';
    errorMessage = '';
    movie: Movie | undefined;

    constructor(private route: ActivatedRoute, private movieService: MovieService, private router: Router) {
        
    }

    ngOnInit(): void {
        const param = this.route.snapshot.paramMap.get('id');
        if (param) {
          const id = +param;
          this.getMovie(id);
        }
        
      }

      getMovie(id: number) {
        this.movieService.getMovie(id).subscribe(movie => {
          this.movie = movie;
        });
      }

      onBack(): void {
        this.router.navigate(['/movies', this.movie.titleId]);
      }
}