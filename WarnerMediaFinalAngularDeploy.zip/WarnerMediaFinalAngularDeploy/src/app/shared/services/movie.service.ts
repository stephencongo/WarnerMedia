import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

import { Movie } from 'src/app/shared/objects/movie';

@Injectable({
    providedIn: 'root'
})

export class MovieService {

    private movieUrl = 'https://localhost:44384/movie';

    constructor(private http: HttpClient) { }

    getMovies(filterBy: string): Observable<Movie[]> {
      
      return this.http.get<Movie[]>(this.movieUrl + '/search/' + filterBy);
    }

    getMovie(id: number): Observable<Movie> {
        return this.http.get<Movie>(this.movieUrl + '/' + id.toString()).pipe(
            tap(data => console.log('All: ' + JSON.stringify(data))),
            catchError(this.handleError)
        );
    }

      private handleError(err: HttpErrorResponse) {
        
        let errorMessage = '';
        if (err.error instanceof ErrorEvent) {
          
          errorMessage = `An error occurred: ${err.error.message}`;
        } else {
          
          errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
      }

}