export class Movie {
    titleId: number;
    titleName: string;
    titleNameSortable: string;
    titleTypeId: number;
    releaseYear: number;
    processedDateTimeUTC: Date;
}