﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WarnerMediaInterview.API.ViewModels
{
    public class OtherName
    {
        public int OtherNameId { get; set; }
        public string TitleNameLanguage { get; set; }
        public string TitleNameType { get; set; }
        public string TitleName { get; set; }
    }
}
