﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WarnerMediaInterview.API.ViewModels
{
    public class StoryLine
    {
        public int StoryLineId { get; set; }
        public string StoryType { get; set; }
        public string StoryLanguage { get; set; }
    }
}
