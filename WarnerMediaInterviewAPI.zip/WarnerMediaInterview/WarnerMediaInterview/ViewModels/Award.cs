﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WarnerMediaInterview.API.ViewModels
{
    public class Award
    {
        public int AwardId { get; set; }
        public bool AwardWon { get; set; }
        public int AwardYear { get; set; }
        public string AwardDescription { get; set; }
        public string AwardCompany { get; set; }
    }
}
