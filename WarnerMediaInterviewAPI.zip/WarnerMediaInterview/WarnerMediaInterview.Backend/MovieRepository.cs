﻿using System;
using System.Collections.Generic;
using System.Text;
using WarnerMediaInterview.Backend.DataObjects;
using Microsoft.Extensions.Configuration;
using Dapper;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace WarnerMediaInterview.Backend
{
    public interface IMovieRepository
    {
        Task<List<Title>> GetTitlesBySearchStringAsync(string searchString);
        Task<Title> GetTitleAsync(int titleId);
    }
    public class MovieRepository : IMovieRepository
    {
        IConfiguration _config;
        private string Connectionstring = "ConnectionString";
        public MovieRepository(IConfiguration config)
        {
            _config = config;
        }
        public async Task<List<Title>> GetTitlesBySearchStringAsync(string searchString)
        {
            var dbParams = new { SearchString = searchString };
            //use spGetMoviesSearch stored proc to search for movies by search string.

            using (var db = new SqlConnection(_config[Connectionstring]))
            {
                var titles = await db.QueryAsync<Title>("exec spGetMoviesSearch @SearchString", dbParams);
                return titles.ToList();
            }

          
        }

        public async Task<Title> GetTitleAsync(int titleId)
        {
            var dbParams = new { TitleId = titleId };
            
            using (var db = new SqlConnection(_config[Connectionstring]))
            {
                //stored proc returns multip queries to hydrate Title object that will be returned.
                var multi = await db.QueryMultipleAsync("exec spGetTitle @TitleId", dbParams);
                var title = multi.Read<Title>().SingleOrDefault();
                var genre = multi.Read<Genre>().ToList();
                var participants = multi.Read<Participant>().ToList();
                var storyLines = multi.Read<StoryLine>().ToList();
                var otherNames = multi.Read<OtherName>().ToList();
                var awards = multi.Read<Award>().ToList();

                if(title != null)
                {
                    title.Genres = genre;
                    title.Participants = participants;
                    title.StoryLines = storyLines;
                    title.OtherNames = otherNames;
                    title.Awards = awards;
                }

                return title;
            }
        }
    }
}
