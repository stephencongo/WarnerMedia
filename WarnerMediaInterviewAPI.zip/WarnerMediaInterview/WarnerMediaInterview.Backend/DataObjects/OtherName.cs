﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarnerMediaInterview.Backend.DataObjects
{
    public class OtherName
    {
        public int OtherNameId { get; set; }
        public string TitleNameLanguage { get; set; }
        public string TitleNameType { get; set; }
        public string TitleName { get; set; }

    }
}
