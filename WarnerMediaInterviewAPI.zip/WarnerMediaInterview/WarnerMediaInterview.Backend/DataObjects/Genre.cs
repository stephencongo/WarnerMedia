﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarnerMediaInterview.Backend.DataObjects
{
    public class Genre
    {
        public int GenreId { get; set; }
        public string GenreName { get; set; }
    }
}
