﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarnerMediaInterview.Backend.DataObjects
{
    public class Award
    {
        public int AwardId { get; set; }
        public bool AwardWon { get; set; }
        public int AwardYear { get; set; }
        public string AwardDescription { get; set; }
        public string AwardCompany { get; set; }

    }
}
