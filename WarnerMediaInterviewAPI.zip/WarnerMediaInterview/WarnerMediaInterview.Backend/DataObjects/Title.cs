﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarnerMediaInterview.Backend.DataObjects
{
    public class Title
    {
        public int TitleId { get; set; }
        public string TitleName { get; set; }
        public string TitleNameSortable { get; set; }
        public int TitleTypeId { get; set; }
        public int ReleaseYear { get; set; }
        public DateTime ProcessedDateTimeUTC { get; set; }

        public List<Participant> Participants { get; set; }
        public List<Award> Awards { get; set; }
        public List<Genre> Genres { get; set; }
        public List<OtherName> OtherNames { get; set; }
        public List<StoryLine> StoryLines { get; set; }
    }
}
