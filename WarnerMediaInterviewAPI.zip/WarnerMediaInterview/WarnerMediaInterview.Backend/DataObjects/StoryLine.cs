﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarnerMediaInterview.Backend.DataObjects
{
    public class StoryLine
    {
        public int StoryLineId { get; set; }
        public string StoryType { get; set; }
        public string StoryLanguage { get; set; }

    }
}
