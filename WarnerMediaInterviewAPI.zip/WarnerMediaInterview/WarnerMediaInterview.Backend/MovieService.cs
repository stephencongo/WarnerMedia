﻿using System;
using System.Collections.Generic;
using WarnerMediaInterview.Backend.DataObjects;
using System.Text;
using System.Threading.Tasks;

namespace WarnerMediaInterview.Backend
{
    public interface IMovieService
    {
        Task<List<Title>> GetMovieTitleSearchAsync(string searchString);
        Task<Title> GetTitleAsync(int titleId);
    }
    public class MovieService : IMovieService
    {
        IMovieRepository _movieRepository;
        public MovieService(IMovieRepository movieRepository)
        {
            _movieRepository = movieRepository;
        }

        public async Task<List<Title>> GetMovieTitleSearchAsync(string searchString)
        {
            var titles = await _movieRepository.GetTitlesBySearchStringAsync(searchString);
            return titles;
        }

        public async Task<Title> GetTitleAsync(int titleId)
        {
            var title = await _movieRepository.GetTitleAsync(titleId);
            return title;
        }
    }
}
